
from setuptools import setup, find_packages


setup(
    name='flixit',
    version='0.6',
    license='MIT',
    author="Aniket Chopade",
    author_email='email@example.com',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    url='https://github.com/Aniket29-shiv/flixit_pypi',
    keywords='example project',
    install_requires=[
          
      ],

)